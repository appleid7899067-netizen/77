import { cn } from "@/lib/utils";

export function LumenMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("text-foreground", className)}
      fill="none"
      aria-hidden="true"
    >
      <circle cx="16" cy="16" r="13" stroke="currentColor" strokeWidth="1.4" opacity="0.35" />
      <circle cx="16" cy="16" r="8" stroke="currentColor" strokeWidth="1.4" opacity="0.7" />
      <circle cx="16" cy="16" r="3.2" fill="currentColor" />
      <path
        d="M16 3v5.5M16 23.5V29M3 16h5.5M23.5 16H29"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        opacity="0.85"
      />
    </svg>
  );
}
